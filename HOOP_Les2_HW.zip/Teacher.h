#pragma once
using namespace std;
#include <string>

class Teacher
{
public:

	string Name = "";

	Teacher();
	Teacher(string name);
	~Teacher();

private:

};