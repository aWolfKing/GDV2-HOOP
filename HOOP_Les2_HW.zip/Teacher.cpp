#pragma once
#include "Teacher.h"

Teacher::Teacher()
{
}

Teacher::Teacher(string name) {
	Name = name;
}

Teacher::~Teacher()
{
}